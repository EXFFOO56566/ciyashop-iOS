=== PGS Woo Api ===
Contributors: potenzaglobalsolutions
Tags: woo commerce, ecommerce, e-commerce, store, sales, sell, shop, cart, checkout, downloadable, downloads, paypal, rest api, api, auth
Requires at least: 4.4
Tested up to: 4.8
Stable tag: 3.3.0
License: GPLv2 or later
License: URI: http://www.gnu.org/licenses/gpl-2.0.html
support-URI:https://potezasupport.ticksy.com?id=
document-URL:http://docs.potenzaglobalsolutions.com/docs/ciya-shop-mobile-apps?id=
PGS Woo Api is a powerful, extendable eCommerce plugin for WooCommerce Rest API.

== Description ==
PGS Woo Api is a peimium plugin for create ecommerce mobile application with Aouth 1.0. This plugin provide Option settings for manage dynamicaly home screen.feature box etc options. Multilanguage support.  

== Installation ==
= Minimum Requirements =

* PHP version 5.6 or greater (PHP 5.6 or greater is recommended)
* MySQL version 5.0 or greater (MySQL 5.6 or greater is recommended)
* PGS Woo Api 1.0 requires WordPress 4.4+
* PGS Woo Api 1.0 requires WooCommerce 3.1+
* PGS Woo Api 1.0 requires WordPress REST API (Version 2)
* PGS Woo Api 1.0 requires WP REST API - OAuth 1.0a Server


== Frequently Asked Questions ==
= A question that someone might have =
An answer to that question.

= What about foo bar? =
Answer to foo bar dilemma.

== Screenshots ==


== Changelog ==
== Version 3.3.0
* Added: Added code re-verification on update plugin process.
* Fixed: Fixed undefined index notice.
* Updated language files.

== Version 3.2.0
* Added: New auto-update functionality.
* Added: Added popup alert.

== Version 3.1.3
* Added: - Codecanyon copy for validate item key
* Added: - Auto Update functionality